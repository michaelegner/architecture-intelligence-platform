import os,json,subprocess,shutil,datetime
from pathlib import Path
root=Path('/tmp/aip-i6.2-rc2-candidate');raw=Path('/home/michael/code/ArchitectureIntelligencePlatform/tmp/i6.2-rc2');up=raw/'upstream'
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();env=os.environ.copy();env.update(AIP_BUILD_REVISION=sha,PYTHONPATH=str(root))
binpath=Path('/tmp/aip-i6.2-rc2-bin');binpath.mkdir(exist_ok=True);link=binpath/'docker'
if not link.exists():link.symlink_to(up/'demo-docker-wrapper.py')
env.update(I5_REAL_DOCKER=shutil.which('docker'),I5_DEMO_PROJECT='aip-qsh-i6-rc2',I5_DEMO_CANDIDATE=sha,PATH=str(binpath)+':'+env['PATH'])
local=root/'.aip-qsh-demo'
assert not local.exists()
assert subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=root)==b''
results=json.loads((raw/'remaining-results.json').read_text())
def run(name,cmd,environment=env):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (raw/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,started=start,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=r.returncode));(raw/'remaining-results.json').write_text(json.dumps(results,indent=2));print(name,r.returncode,flush=True);return r.returncode
try:
 if run('clean-original-demo',['bash','examples/quarkus-super-heroes-demo/run.sh']):raise RuntimeError('demo failed')
 if run('clean-original-demo-checks',[str(root/'.venv/bin/python'),str(up/'demo-checks.py'),str(up/'demo')]):raise RuntimeError('demo checks failed')
finally:run('clean-original-demo-teardown',['bash','examples/quarkus-super-heroes-demo/run.sh','--down'])

assert subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=root)==b''
