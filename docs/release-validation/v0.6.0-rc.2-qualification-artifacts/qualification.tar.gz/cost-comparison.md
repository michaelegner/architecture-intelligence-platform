Observed local medians; hardware/runtime variation applies. The retained I4 baseline is comparison evidence, not a performance threshold.

| Locality point | Prior I4 ms | Final candidate ms |
|---|---:|---:|
| churn (N=0, S=1, W=2, O=1) | 112.9 | 128.3 |
| churn (N=100, S=1, W=2, O=1) | 142.8 | 130.9 |
| churn (N=1000, S=1, W=2, O=1) | 736.9 | 641.0 |
| workload-cap (N=60, S=1, W=60, O=1) | 137.8 | 120.9 |
| membership-cap (N=1, S=1, W=1, O=201) | 476.0 | 392.1 |
| fan-out (N=500, S=1, W=1, O=1) | 476.5 | 393.0 |
| fan-out (N=500, S=5, W=1, O=1) | 412.2 | 345.7 |
| fan-out (N=500, S=50, W=1, O=1) | 188.3 | 205.7 |
| covering-fan-out (N=400, S=5, W=1, O=1) | 2921.3 | 2338.1 |
| covering-fan-out (N=40, S=50, W=1, O=1) | 2337.0 | 1686.6 |

| Churn Pods | Mode | Prior persistence ms/post | Final persistence ms/post | Prior snapshot ms | Final snapshot ms |
|---:|---|---:|---:|---:|---:|
| 0 | off | — | — | 99.8 | 83.3 |
| 0 | on | — | — | 77.8 | 63.2 |
| 100 | off | 1208.9 | 1183.8 | 52.7 | 43.1 |
| 100 | on | 1786.3 | 1666.5 | 70.0 | 54.0 |
| 1000 | off | 990.0 | 781.7 | 98.0 | 83.3 |
| 1000 | on | 1474.9 | 1120.7 | 263.2 | 218.0 |

All ten locality points have zero stable-read retries and zero cursor-walk refusals. Complete cap, pair-disposition, retained-state and replacement outputs are in the JSON reports. The original retained-state limitations remain: records grow with Pod churn and there is no retention/compaction policy.
