#!/usr/bin/env python3
"""Qualification-only wrapper: stamp candidate build, then run the unchanged one-command demo."""
import json,os,subprocess,sys
from pathlib import Path
real=os.environ['I5_REAL_DOCKER']; args=sys.argv[1:]
args=[os.environ['I5_DEMO_PROJECT'] if x=='aip-qsh-demo' else x for x in args]
log=Path('/home/michael/code/ArchitectureIntelligencePlatform/tmp/i6.2-rc2/upstream/demo-commands.jsonl')
with log.open('a') as f:f.write(json.dumps(args)+'\n')
if 'compose' in args and 'up' in args and '--build' in args:
 prefix=args[:args.index('up')]
 subprocess.run([real,*prefix,'build','--build-arg','AIP_BUILD_REVISION='+os.environ['I5_DEMO_CANDIDATE'],'architecture-intelligence'],check=True)
 args=[x for x in args if x!='--build']+['--no-build']
os.execv(real,[real,*args])
