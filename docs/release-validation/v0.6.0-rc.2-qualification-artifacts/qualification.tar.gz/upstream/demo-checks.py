"""Check the existing demo's frozen answer/snapshot pins on an explicitly stamped candidate image."""
import hashlib,importlib.util,json,os,re,sys
from pathlib import Path
import httpx,neo4j
from app.architecture_intelligence.canonical_json import canonical_json_bytes
from app.architecture_intelligence.repository import canonical_snapshot_state,read_stable_snapshot_from_session
from tests.integration.independent_mcp_client import call_tool,tools_list
root=Path('/tmp/aip-i6.2-rc2-candidate');out=Path(sys.argv[1]);out.mkdir(exist_ok=True)
sha=(out.parent/'candidate-sha').read_text().strip()
spec=importlib.util.spec_from_file_location('qsh_ready',root/'examples/quarkus-super-heroes-demo/check_ready.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
records=root/'.aip-qsh-demo'
for name in ('context.json','import.json','dependencies.json','prompt.txt'): (out/name).write_bytes((records/name).read_bytes())
def save(name,value): (out/name).write_bytes(canonical_json_bytes(value))
with httpx.Client(base_url='http://localhost:8000',timeout=60) as client:
 headers={'content-type':'application/json','accept':'application/json, text/event-stream','mcp-protocol-version':'2025-11-25'}
 r=client.post('/mcp',headers=headers,json={'jsonrpc':'2.0','id':0,'method':'initialize','params':{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'i5-demo-check','version':'1'}}});r.raise_for_status();save('initialize.json',r.json())
 tools=tools_list(client);save('tools-list.json',tools)
 assert [t['name'] for t in tools['tools']]==['get_architecture_drift','get_evidence','get_service_dependencies','get_service_dependencies_by_locality']
 request={'service_id':mod.SERVICE_ID,'observation_context':mod.CONTEXT};answer=call_tool(client,name='get_service_dependencies',arguments={'request':request})['structuredContent'];save('dependencies.mcp.json',answer)
 assert mod.check_answer(answer)==[]
 assert answer['producer']['build_revision']==sha
 pin=re.search(r'aip:snapshot:v1:[0-9a-f]{64}',(root/'examples/quarkus-super-heroes-demo/walkthrough.md').read_text()).group()
 assert answer['snapshot']['snapshot_id']==pin
 drift=call_tool(client,name='get_architecture_drift',arguments={'request':{'service_id':mod.SERVICE_ID,'observation_context':mod.CONTEXT}})['structuredContent']
 r=client.get('/api/services/'+mod.SERVICE_ID+'/drift',params={'environment':mod.CONTEXT['environment'],'from':mod.CONTEXT['window_start'],'to':mod.CONTEXT['window_end']});r.raise_for_status()
 save('drift.mcp.json',drift);save('drift.rest.json',r.json())
 assert canonical_json_bytes(drift)==canonical_json_bytes(r.json())
 assert drift['snapshot']['snapshot_id']==pin and drift['producer']['build_revision']==sha
 assert drift['outcome']=='PARTIAL' and len(drift['claims'])==5
 assert all(c['qualification']=='NOT_OBSERVED_IN_WINDOW' for c in drift['claims'])
 expected_calls={op:q for op,q in mod.EXPECTED_CALLS.items() if q=='NOT_OBSERVED_IN_WINDOW'}
 actual_calls={c['delivery']['via']['id']:c['qualification'] for c in drift['claims'] if mod.relation(c)=='CALLS'}
 assert actual_calls==expected_calls
 published=[c for c in drift['claims'] if mod.relation(c)=='PUBLISHES_TO']
 assert len(published)==1 and {k:published[0].get(k) for k in mod.EXPECTED_PUBLISH}==mod.EXPECTED_PUBLISH
 refs=answer['evidence_refs'];request={'evidence_refs':refs,'snapshot_id':pin};evidence=call_tool(client,name='get_evidence',arguments={'request':request})['structuredContent'];save('evidence.request.json',request);save('evidence.mcp.json',evidence)
 assert evidence['outcome']=='ANSWERED' and evidence['data']['missing_evidence_refs']==[]
 request={'environment':'quarkus-i5','first_day':'2026-09-25','last_day':'2026-09-25'}
 r=client.post('/api/services/service:rest-fights/dependencies/by-locality',json=request);r.raise_for_status();locality=r.json();save('missing-local-observation.request.json',request);save('missing-local-observation.rest.json',locality)
 assert locality['data']['candidates']==locality['data']['localities']==[]
 assert locality['data']['inventory']['completeness']=='COMPLETE'
 assert locality['data']['coverage']=='LOCAL_WORKLOAD_COVERAGE_UNAVAILABLE'
 assert 'NOT_OBSERVED_IN_WINDOW' not in json.dumps(locality)
# Read canonical snapshot from the demo graph, using its local disposable password without publishing it.
password=(records/'neo4j-password').read_text().strip()
# Read inside the candidate container via Docker separately; demo Neo4j has no host Bolt port.
save('summary.json',{'candidate_sha':sha,'status':'CORRECT','snapshot_id':pin,'four_tools':True,'no_locality_claims':True,'all_evidence_resolved':True,'original_drift_facts_preserved':True})
print(json.dumps({'status':'CORRECT','snapshot_id':pin}))
