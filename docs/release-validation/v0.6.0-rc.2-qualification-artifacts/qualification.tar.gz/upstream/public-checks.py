"""Execute existing v0.5 public-surface checks; v0.6 tools/list follows frozen I3 four-tool contract."""
import hashlib,json,os,sys
from pathlib import Path
import httpx,neo4j
from app.settings import load_config
from app.architecture_intelligence.bootstrap import build_production_service,production_service_kwargs
from app.architecture_intelligence.canonical_json import canonical_json_bytes
from app.architecture_intelligence.request import ServiceDependenciesRequest,ArchitectureDriftRequest,EvidenceRequest
from app.architecture_intelligence.locality_contracts import LocalityQueryRequest
from tests.integration.independent_mcp_client import tools_list,call_tool

root=Path('/tmp/aip-i6.2-rc2-candidate'); out=Path(sys.argv[1]); system=sys.argv[2]
runtime=root/'docs/real-world-validation/v0.5.0'/system/'runtime'
os.chdir(runtime)
os.environ['AIP_BUILD_REVISION']=(out/'candidate-sha').read_text().strip()
config=load_config(Path('config.quarkus-i5.yaml' if system=='quarkus-super-heroes' else 'config.airflow-i5.yaml'))
driver=neo4j.GraphDatabase.driver('bolt://localhost:7687',auth=('neo4j','i5-disposable'))
service=build_production_service(driver,**production_service_kwargs(config))
records=out/'public-surfaces'; records.mkdir(exist_ok=True)
def save(name,value): (records/name).write_bytes(canonical_json_bytes(value))
query=(root/'docs/real-world-validation/v0.5.0/queries/Q-GRAPH.cypher').read_text()
def graph():
 with driver.session(default_access_mode=neo4j.READ_ACCESS) as session:
  rows=[]
  for r in session.run(query):
   e=r['entity']; row={'kind':r['kind'],'id':r['id'],'properties':dict(e)}
   if hasattr(e,'labels'): row['labels']=sorted(e.labels)
   else: row|={'type':e.type,'start':e.start_node.element_id,'end':e.end_node.element_id}
   rows.append(row)
  return json.dumps(rows,sort_keys=True,separators=(',',':'),default=str).encode()
before=graph(); (records/'q-graph-before.json').write_bytes(before)
context={'environment':'quarkus-i5' if system=='quarkus-super-heroes' else 'airflow-i5','window_start':(out/'window-start').read_text().strip(),'window_end':(out/'window-end').read_text().strip()}
subject='service:rest-fights' if system=='quarkus-super-heroes' else 'service:airflow-apiserver'
passed=[]
with httpx.Client(base_url='http://localhost:8000',timeout=60) as client:
 headers={'content-type':'application/json','accept':'application/json, text/event-stream','mcp-protocol-version':'2025-11-25'}
 initialized=client.post('/mcp',headers=headers,json={'jsonrpc':'2.0','id':0,'method':'initialize','params':{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'i5-upstream-http-check','version':'1'}}})
 initialized.raise_for_status(); save('initialize.json',initialized.json())
 tools=tools_list(client); save('tools-list.json',tools)
 assert [t['name'] for t in tools['tools']]==['get_architecture_drift','get_evidence','get_service_dependencies','get_service_dependencies_by_locality']
 answers={}
 for name,request_type,method,route in [('dependencies',ServiceDependenciesRequest,'get_service_dependencies','dependencies'),('drift',ArchitectureDriftRequest,'get_architecture_drift','drift')]:
  request={'service_id':subject,'observation_context':context}; save(name+'.request.json',request)
  direct=getattr(service,method)(request_type.model_validate(request)).model_dump(mode='json')
  response=client.get('/api/services/'+subject+'/'+route,params={'environment':context['environment'],'from':context['window_start'],'to':context['window_end']}); response.raise_for_status()
  rest=response.json(); mcp=call_tool(client,name=method,arguments={'request':request})
  for adapter,value in [('service',direct),('rest',rest),('mcp',mcp['structuredContent'])]:save(name+'.'+adapter+'.json',value)
  save(name+'.mcp.transport.json',mcp)
  assert canonical_json_bytes(direct)==canonical_json_bytes(rest)==canonical_json_bytes(mcp['structuredContent'])
  assert direct['producer']['build_revision']==os.environ['AIP_BUILD_REVISION']
  answers[name]=direct; passed.append(name)
 assert answers['dependencies']['snapshot']==answers['drift']['snapshot']
 refs=sorted(set(answers['dependencies']['evidence_refs']) | {ref for claim in answers['dependencies']['claims'] for ref in (*claim.get('evidence_refs',[]),*claim.get('resolution_evidence_refs',[]))})
 for offset in range(0,len(refs),20):
  request={'evidence_refs':refs[offset:offset+20],'snapshot_id':answers['dependencies']['snapshot']['snapshot_id']}; name='evidence-'+str(offset//20)
  direct=service.get_evidence(EvidenceRequest.model_validate(request)).model_dump(mode='json')
  response=client.post('/api/evidence/resolve',json=request);response.raise_for_status();mcp=call_tool(client,name='get_evidence',arguments={'request':request})
  save(name+'.request.json',request)
  for adapter,value in [('service',direct),('rest',response.json()),('mcp',mcp['structuredContent'])]: save(name+'.'+adapter+'.json',value)
  assert canonical_json_bytes(direct)==canonical_json_bytes(response.json())==canonical_json_bytes(mcp['structuredContent'])
  assert direct['data']['missing_evidence_refs']==[]
  passed.append(name)
 # Missing-local-observation negative on genuine upstream state, separately from controlled reference.
 day=context['window_start'][:10]
 request={'mode':'query','subject_service_id':subject,'environment':context['environment'],'first_day':day,'last_day':day}
 response=client.post('/api/services/'+subject+'/dependencies/by-locality',json={k:v for k,v in request.items() if k not in ('mode','subject_service_id')});response.raise_for_status();answer=response.json()
 save('missing-local-observation.request.json',request);save('missing-local-observation.rest.json',answer)
 direct=service.get_service_dependencies_by_locality(LocalityQueryRequest.model_validate(request)).model_dump(mode='json')
 mcp=call_tool(client,name='get_service_dependencies_by_locality',arguments={'request':request})['structuredContent']
 save('missing-local-observation.service.json',direct);save('missing-local-observation.mcp.json',mcp)
 assert canonical_json_bytes(direct)==canonical_json_bytes(answer)==canonical_json_bytes(mcp)
 assert answer['producer']['build_revision']==os.environ['AIP_BUILD_REVISION']
 assert answer['data']['candidates']==answer['data']['localities']==[]
 assert answer['data']['coverage']=='LOCAL_WORKLOAD_COVERAGE_UNAVAILABLE'
 assert 'NOT_OBSERVED_IN_WINDOW' not in json.dumps(answer)
 passed.append('missing-local-observation')
manual=out/'manual-checks'; manual.mkdir(exist_ok=True)
with driver.session(default_access_mode=neo4j.READ_ACCESS) as session:
 for query_path in sorted((root/'docs/real-world-validation/v0.5.0/queries').glob('*.cypher')):
  if query_path.name=='Q-GRAPH.cypher': continue
  rows=[dict(record) for record in session.run(query_path.read_text())]
  (manual/(query_path.stem+'.json')).write_text(json.dumps(rows,sort_keys=True,default=str)+'\n')
 assert session.run('MATCH (n) WHERE n:Queue OR n:Topic OR n:Subscription RETURN count(n) AS c').single()['c']==0
 if system=='apache-airflow':
  assert [r['id'] for r in session.run('MATCH (s:Service) RETURN s.id AS id ORDER BY id')]==['service:airflow-apiserver']
 else:
  assert session.run("MATCH (i:InfrastructureEntity {entity_kind:'KUBERNETES_WORKLOAD'}) RETURN count(i) AS c").single()['c']==13
  assert [r['mode'] for r in session.run('MATCH (c:InfrastructureContribution) RETURN DISTINCT c.evidence_mode AS mode ORDER BY mode')]==['DECLARED_MANIFEST']
 (manual/'ground-truth-checks.json').write_text(json.dumps({'no_messaging_entities':True,'upstream_mode_preserved':True})+'\n')
after=graph();(records/'q-graph-after.json').write_bytes(after);assert before==after
save('summary.json',{'candidate_sha':os.environ['AIP_BUILD_REVISION'],'status':'CORRECT','passed':passed,'evidence_refs':len(refs),'zero_write_sha256':hashlib.sha256(before).hexdigest(),'snapshot':answers['dependencies']['snapshot']})
driver.close(); print(json.dumps({'status':'CORRECT','passed':passed}))
