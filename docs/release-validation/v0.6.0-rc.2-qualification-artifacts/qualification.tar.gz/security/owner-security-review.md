# rc.2 candidate security disposition

Candidate: `8102b8e4f1010c2c0d1395b91c79f3cd4c63429a`. Image: `sha256:86c0e84a0567800db69a03f7c5977a921ffb4f7296d4d0d6551f3e02a131b57b`.

Pinned Trivy 0.70.0 scanned HIGH/CRITICAL including unfixed findings. Full report: `trivy-candidate.json`; candidate SBOM: `sbom.cdx.json`. **55 HIGH, zero CRITICAL.**

The baseline final full report has 46 HIGH findings, carried forward unchanged by the v0.5.1 release record. All 46 remain. There are nine newly reported package findings, representing five additional vulnerability IDs:

| Findings | Packages / vulnerability | Fix available |
|---|---|---|
| 1 HIGH | Debian libpcre2-8-0, CVE-2026-103111: crafted-regex out-of-bounds write | Yes |
| 6 HIGH | Debian libssl3t64, openssl and openssl-provider-legacy; CVE-2026-75804 (QUIC flow-control DoS), CVE-2026-84782 (DTLS handshake information disclosure) | Yes |
| 2 HIGH | Base-image pip-vendored urllib3 2.7.0; CVE-2026-97687 (HTTPS proxy TLS configuration override), CVE-2026-97689 (chunk-parser memory DoS) | Yes |

The other two Python HIGH findings are the previously accepted pip vendors msgpack and setuptools. Runtime inspection confirms pip, msgpack, setuptools and urllib3 are absent from the isolated AIP virtual environment; the vulnerable copies are in the base image's system pip vendor tree. This bounds the Python exposure; it does not assert that Debian OS findings are universally unreachable or harmless.

The pinned Python base is unchanged; newly reported findings are not introduced by an AIP runtime dependency addition. Runtime dependency upgrades and the locked environment were reviewed, and exact-SHA pip-audit, Semgrep and both CodeQL analysis jobs passed. #323 is fixed and closed. All 42 redacted gitleaks hits were classified as pinned public demo credentials, sanitized placeholders or SHA-256 digests; no live secret was identified.

**Owner disposition: ACCEPTED.** Michael Egner confirmed: “I confirm both -> GO”. All 55 HIGH findings are accepted as documented non-blocking limitations for this exact candidate/image and bounded release. This does not authorize publication or establish production security/capacity. The published digest still requires its own security comparison and disposition.

The completed raw-evidence scan reports 212 redacted false positives: 196 source-file SHA-256 digests in qualification ledgers and 16 credentials in the unchanged pinned public Quarkus demonstration manifest. No live secret or new evidence exposure was identified; disposable Neo4j passwords and fresh source clones are excluded from publication.
