import os,json,subprocess,shutil,datetime
from pathlib import Path
root=Path('/tmp/aip-i6.2-rc2-candidate');raw=Path('/home/michael/code/ArchitectureIntelligencePlatform/tmp/i6.2-rc2');up=raw/'upstream'
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();env=os.environ.copy();env.update(AIP_BUILD_REVISION=sha,PYTHONPATH=str(root))
binpath=Path('/tmp/aip-i6.2-rc2-bin');binpath.mkdir(exist_ok=True);link=binpath/'docker'
if not link.exists():link.symlink_to(up/'demo-docker-wrapper.py')
env.update(I5_REAL_DOCKER=shutil.which('docker'),I5_DEMO_PROJECT='aip-qsh-i6-rc2',I5_DEMO_CANDIDATE=sha,PATH=str(binpath)+':'+env['PATH'])
results=json.loads((raw/'remaining-results.json').read_text())
def run(name,cmd,environment=env):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (raw/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,started=start,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=r.returncode));(raw/'remaining-results.json').write_text(json.dumps(results,indent=2));print(name,r.returncode,flush=True);return r.returncode
plain=os.environ.copy();plain.update(AIP_BUILD_REVISION=sha,RELEASE_CANDIDATE_SHA=sha,PYTHONPATH=str(root))
for name,cmd in [('golden',['bash','examples/release-golden-path/run.sh','aip-v0.6.0-rc2:'+sha,str(raw/'golden-retry')]),('churn',['uv','run','python','-m','benchmarks.scoped_churn_cost','--profile','i2','--candidate-sha',sha,'--out',str(raw/'churn.json')]),('locality',['uv','run','python','-m','benchmarks.locality_cost','--profile','i3','--candidate-sha',sha,'--out',str(raw/'locality.json')])]:
 if run(name+'-retry',cmd,plain):raise RuntimeError(name+' failed')

subprocess.run(['python3','/tmp/i6-clean-demo.py'],check=True)
