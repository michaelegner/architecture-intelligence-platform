# v0.6.0 final-image security review

Image: `ghcr.io/michaelegner/architecture-intelligence-platform@sha256:382067552fbfa7c27acafa204af03372839f1980c9801339bf656c2dfd928fea`

Publication workflow: https://github.com/michaelegner/architecture-intelligence-platform/actions/runs/37366066247, attempt 1, success.

The digest-bound full HIGH/CRITICAL report and CycloneDX SBOM are retained in the merged I6.4 publication archive. Candidate/final comparison preserves package identity, installed/fixed versions, severity and status: **55 HIGH, zero CRITICAL; zero new and zero removed findings**. The same 51 Debian OS findings and four base-image system-pip vendor findings were accepted for the exact candidate. The isolated AIP environment excludes those pip vendors; Debian OS findings are not claimed universally unreachable. Nine candidate additions have fixes available (PCRE2/OpenSSL/urllib3); this final review does not claim production security.

Tag scanning compared with v0.5.1: **46 open Trivy alerts**, previously three. The 43 additional entries comprise nine HIGH already present in the accepted candidate full report, 28 MEDIUM and six LOW across 17 vulnerability IDs. The MEDIUM/LOW additions are OpenSSL (27 MEDIUM/six LOW) and base-image pip-vendored urllib3 (one MEDIUM, CVE-2026-97688, chunked Deflate decoding DoS; fix 2.8.0). They have fixes available and are retained for final disposition. Exact-candidate CodeQL passed in I6.2; CodeQL does not trigger on tags. #323 is fixed in the candidate and closed.

The anonymous immutable pull, exact tag/image/source identities, all six golden-path phases and 17-case locality replay pass. No final-artifact mismatch or new HIGH/CRITICAL finding was discovered.

**Final owner disposition: PENDING.** Proposed disposition: accept the complete retained final-image findings as documented non-blocking limitations for this exact published digest and bounded v0.6.0 release. This leaves production security/capacity unestablished and preserves all release limitations. It is not a request to authorize publication again.
