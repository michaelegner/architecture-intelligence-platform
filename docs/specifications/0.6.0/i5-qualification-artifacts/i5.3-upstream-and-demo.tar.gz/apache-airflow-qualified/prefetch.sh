# I5.3: owner-approved host path deviation; relocated records; disposable DB password; clone object cache only. Frozen procedure otherwise unchanged.
#!/usr/bin/env bash
# Generated from the frozen runbook docs/real-world-validation/v0.5.0/apache-airflow/runbook.md (blocks 1-10, verbatim) at candidate 174a17c.
# Deviations: RUN_DIR fixed; NEO4J_PASSWORD from a 0600 file; the v0.3 readiness helpers the
# runbook names, with their bare 'docker compose' calls routed through frozen_compose (the
# frozen rule; a bare call would miss the fixed project name); window bounds saved to files.
export AIP_CHECKOUT=/tmp/aip-i5.3
export DOSSIER="$AIP_CHECKOUT/docs/real-world-validation/v0.5.0/apache-airflow"
export RUNTIME="$DOSSIER/runtime"
export RUN_DIR=/home/michael/code/ArchitectureIntelligencePlatform/tmp/i5.3/apache-airflow-qualified
# Every Compose call goes through frozen_compose (PR #243 review). It uses exactly the frozen
# file, a fixed project name and no env file. So it ignores any gitignored .env (which could set
# COMPOSE_FILE) and any docker-compose.override.yml; the clean-checkout gate can see neither.
frozen_compose() {
  docker compose -p airflow-i5 --project-directory "$RUNTIME" -f "$RUNTIME/docker-compose.yml" \
    --env-file /dev/null "$@"
}
export NEO4J_PASSWORD=i5-disposable
export FERNET_KEY="$(python3 -c "import base64, os; print(base64.urlsafe_b64encode(os.urandom(32)).decode())")"
echo '==> runbook block 2'
set -euo pipefail
cd "$AIP_CHECKOUT"
[ "$(pwd -P)" = "$AIP_CHECKOUT" ]                         # the one frozen absolute location (I5 §12)
[ -z "$(git status --porcelain)" ] || { echo "checkout is not clean" >&2; exit 1; }
export AIP_CANDIDATE_SHA="$(git rev-parse HEAD)"
echo "$AIP_CANDIDATE_SHA" | grep -Eq '^[0-9a-f]{40}$'
echo "$AIP_CANDIDATE_SHA" > "$RUN_DIR/candidate-sha"

# The upstream-supplied OpenAPI is byte-identical to the pin (profile.md).
curl -sSfL -o "$RUN_DIR/openapi.yml" \
  https://raw.githubusercontent.com/apache/airflow/3adbbe1c58e4532df1964cb7794805e763816ee8/airflow-core/src/airflow/api_fastapi/core_api/openapi/v2-rest-api-generated.yaml
cmp "$RUN_DIR/openapi.yml" "$RUNTIME/declarations/airflow-apiserver/openapi.yml"
echo '==> runbook block 3'
cd "$RUNTIME"
: "${NEO4J_PASSWORD:?}" "${FERNET_KEY:?}" "${AIP_CANDIDATE_SHA:?}"
unset COMPOSE_PROFILES   # no extra profiles; frozen_compose already fixes the file and ignores .env

# PR #242 review: the run must mount exactly this dossier's frozen Dag directory. The Compose file
# has no environment override for it, and this check proves it on the resolved configuration.
[ "$(frozen_compose config --format json | jq -r '
    [.services[] | .volumes[]? | select(.target == "/opt/airflow/dags") | .source] | unique | .[]')"   = "$RUNTIME/dags" ] || { echo "Dag mount is not $RUNTIME/dags" >&2; exit 1; }

frozen_compose pull --ignore-buildable   # every third-party image is referenced as tag@digest
